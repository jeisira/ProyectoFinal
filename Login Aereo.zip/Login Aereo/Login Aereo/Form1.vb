﻿Imports System.Data.SqlClient
Imports MySql.Data.MySqlClient


Public Class Form1

    Dim conexion1 As New MySqlConnection

#Region "conexion a la base de datos"


    Public Sub conectar()
        Try
            conexion1.ConnectionString = "server=127.0.0.1;user=root;password=andrea-2497;database=compañia_aerea1"
            conexion1.Open()
            MsgBox("conectado correctamente")
        Catch ex As Exception
            MsgBox("No Conectado" + ex.ToString)
            Me.Close()

        End Try


    End Sub
#End Region


    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        conectar()

    End Sub

    Private Sub BtnIniciar_Click(sender As Object, e As EventArgs) Handles BtnIniciar.Click

        Try
            If conexion1.State = ConnectionState.Closed Then
                conexion1.Open()
            End If

            Dim query As String = String.Empty

            query = "SELECT * FROM pilotos WHERE usuario='" & Txtuser.Text & "' And contraseña = '" & Txtpass.Text & " '"

            Dim mysqlcommand As MySqlCommand
            mysqlcommand = New MySqlCommand(query, conexion1)
            Dim tabla As MySqlDataReader

            tabla = mysqlcommand.ExecuteReader
            Dim cantidad As Integer = 0

            While tabla.Read
                cantidad += 1
            End While

            If cantidad = 1 Then
                MsgBox("Usuario y Contraseña Correctas")
                Me.Hide()
                FormPrincipal.show()

            ElseIf cantidad > 1 Then
                MsgBox("ERROR: hay datos duplicados")

            ElseIf Txtuser.Text = "" Or Txtpass.Text = "" Then
                MsgBox("Los campos no pueden estar vacios")

            Else
                MsgBox("ERROR: usuario y contraseña no valida")

            End If
            conexion1.Close()

        Catch ex As Exception
            MsgBox(ex.Message)

        Finally
            conexion1.Dispose()
        End Try
    End Sub
End Class
